| State | 2001 |  |  | 2002 |  |  |  |  |  |
|---|---|---|---|---|---|---|---|---|---|
|  | Total | Crops | Live- stock and prod- ucts | Total | Crops | Livestock and products | State rank for total farm marketings and four principal commodities in order of marketing receipts |  |  |
| U.S. | 199,779 | 93,366 | 106,413 | 192,948 | 99,468 | 93,480 | Cattle, dairy products, corn, greenhouse |  |  |
| AL . . . . . | 3,448 | 632 | 2,816 | 2,962 | 584 | 2,378 | 29-Broilers, cattle, chicken eggs, greenhouse |  |  |
| AK . . . . . | 52 | 23 | 29 | 51 | 23 | 28 | 49-Greenhouse, dairy products, hay, potatoes |  |  |
| AZ . . . . . | 2,601 | 1,409 | 1,192 | 2,997 | 1,903 | 1,094 | 27-Lettuce, cattle, dairy products, cotton |  |  |
| AR . . . . . | 4,966 | 1,450 | 3,516 | 4,527 | 1,575 | 2,952 | 14-Broilers, soybeans, cattle, rice |  |  |
| CA . . . . . | 26,378 | 19,035 | 7,343 | 26,107 | 19,865 | 6,242 | 1-Dairy products, greenhouse, grapes, lettuce |  |  |
| CO . . . . . | 4,719 | 1,346 | 3,373 | 4,881 | 1,379 | 3,502 | 12-Cattle, corn, dairy products, greenhouse |  |  |
| CT . . . . . | 483 | 307 | 175 | 468 | 314 | 154 | 43-Greenhouse, dairy products, chicken eggs, aquaculture |  |  |
| DE | 845 | 187 | 659 | 724 | 177 | 546 | 40-Broilers, greenhouse, corn, soybeans |  |  |
| FL | 6,690 | 5,288 | 1,402 | 6,848 | 5,609 | 1,239 | 8-Greenhouse, oranges, sugar cane, tomatoes |  |  |
| GA | 5.274 | 1,735 | 3.539 | 4,472 | 1,582 | 2,890 | 15-Broilers, chicken eggs, cotton, cattle |  |  |
| HI | 513 | 425 | 88 | 509 | 424 | 85 | 41-Pineapples, greenhouse, sugar cane, macadamia nuts |  |  |
| ID. | 3,714 | 1,652 | 2,062 | 3,934 | 1,935 | 1,999 | 19-Cattle, dairy products, potatoes, wheat |  |  |
| IL...... | 7,308 | 5,461 | 1,846 | 7,486 | 5,924 | 1,562 | 6-Corn, soybeans, hogs, cattle |  |  |
| IN...... | 5,157 | 3,290 | 1,868 | 4,800 | 3,249 | 1,551 | 13-Corn, soybeans, hogs, dairy products |  |  |
| IA....... | 10.653 | 4,728 | 5.926 | 10.834 | 5,759 | 5,075 | 3-Corn, hogs, soybeans, cattle |  |  |
| KS...... | 7.979 | 2.474 | 5.505 | 7,862 | 2,536 | 5,325 | 5-Cattle, wheat, corn, soybeans |  |  |
| KY..... | 3.528 | 1.265 | 2.263 | 3,112 | 1,151 | 1,961 | 24-Horses/mules, tobacco, broilers, cattle |  |  |
| LA | 1,786 | 1,084 | 701 | 1,773 | 1,159 | 614 | 33-Sugar cane, cotton, cattle, corn |  |  |
| ME | 490 | 217 | 273 | 442 | 212 | 230 | 44-Potatoes, dairy products, chicken eggs, aquaculture |  |  |
| MD | 1,596 | 647 | 949 | 1,432 | 621 | 810 | 36-Broilers, greenhouse, dairy products, corn |  |  |
| MA | 367 | 273 | 94 | 380 | 297 | 83 | 45-Greenhouse, cranberries, dairy products, sweet corn |  |  |
| MI | 3,507 | 2,015 | 1,492 | 3,390 | 2,130 | 1,260 | 22-Dairy products, greenhouse, soybeans, corn |  |  |
| MN..... | 7,537 | 3,255 | 4,283 | 7,478 | 3,833 | 3,645 | 7-Corn, soybeans, hogs, dairy products |  |  |
| MS..... | 3,141 | 865 | 2.276 | 2,962 | 1,013 | 1,950 | 28-Broilers, cotton, soybeans, aquaculture |  |  |
| MO...... | 4,723 | 2,039 | 2.684 | 4.402 | 2,100 | 2,302 | 16-Soybeans, cattle, corn, hogs |  |  |
| MT..... | 1,760 | 635 | 1,124 | 1,687 | 702 | 985 | 34-Cattle, wheat, hay, barley |  |  |
| NE..... | 9.221 | 3.126 | 6.095 | 9,589 | 3,764 | 5,824 | 4-Cattle, corn, soybeans, hogs |  |  |
| NV..... | 428 | 157 | 271 | 366 | 155 | 211 | 47-Cattle, hay, dairy products, onions |  |  |
| NH..... | 157 | 90 | 67 | 148 | 91 | 56 | 48-Greenhouse, dairy products, apples, cattle |  |  |
| NJ......... | 837 | 634 | 203 | 856 | 663 | 193 | 39-Greenhouse, horses/mules, blueberries, dairy products |  |  |
| NM....... | 2,213 | 543 | 1,670 | 1,957 | 575 | 1,382 | 32-Dairy products, cattle, hay, greenhouse |  |  |
| NY..... | 3,391 | 1.169 | 2.222 | 3,104 | 1,234 | 1,870 | 25-Dairy products, greenhouse, hay, apples |  |  |
| NC..... | 7,585 | 2,931 | 4,654 | 6,603 | 2,659 | 3,944 | 9-Hogs, broilers, greenhouse, tobacco |  |  |
| ND..... | 2,938 | 2,211 | 727 | 3,223 | 2,499 | 724 | 23-Wheat, cattle, soybeans, sugar beets |  |  |
| OH..... | 4,529 | 2,669 | 1,860 | 4,276 | 2,646 | 1,630 | 17-Soybeans, corn, greenhouse, dairy products |  |  |
| OK..... | 3,937 | 796 | 3,142 | 3,731 | 837 | 2,893 | 21-Cattle, hogs, broilers, wheat |  |  |
| OR..... | 3,127 | 2,302 | 825 | 3,102 | 2,294 | 808 | 26-Greenhouse, cattle, dairy products, hay |  |  |
| PA..... | 4,514 | 1,366 | 3,148 | 4,042 | 1,360 | 2,682 | 18-Dairy products, cattle, agaricus mushrooms, greenhouse |  |  |
| RI...... | 48 | 40 | 8 | 46 | 40 | 6 | 50-Greenhouse, dairy products, sweet corn, potatoes |  |  |
| SC..... | 1,595 | 713 | 883 | 1.452 | 692 | 760 | 35-Broilers, greenhouse, turkeys, tobacco |  |  |
| SD......... | 3,897 | 1.640 | 2.257 | 3,779 | 1,720 | 2,060 | 20-Cattle, corn, soybeans, hogs |  |  |
| TN ..... | 2.118 | 988 | 1,130 | 2,000 | 1,087 | 913 | 31-Cattle, broilers, greenhouse, soybeans |  |  |
| TX | 13,509 | 4,165 | 9,345 | 12,665 | 4,577 | 8,088 | 2-Cattle, greenhouse, cotton, broilers |  |  |
| UT | 1,113 | 257 | 855 | 1,057 | 249 | 808 | 37-Cattle, dairy products, hay, hogs |  |  |
| VT | 558 | 67 | 490 | 476 | 76 | 400 | 42-Dairy products, cattle, greenhouse, maple products |  |  |
| VA | 2,457 | 756 | 1,702 | 2,173 | 722 | 1,451 | 30-Broilers, cattle, dairy products, greenhouse |  |  |
| WA | 5,200 | 3,479 | 1,721 | 5,209 | 3,714 | 1,495 | 11-Apples, dairy products, cattle, potatoes |  |  |
| WW..... | 437 | 89 | 348 | 378 | 78 | 300 | 46-Broiles, cattle, dairy products, chicken eggs |  |  |
| WI..... | 5,761 | 1,290 | 4,471 | 5,319 | 1,551 | 3,768 | 10-Dairy products, call, com, soybeans |  |  |
| WY..... | 995 | 153 | 842 | 876 | 126 | 750 | 38 Cattle, hay, sugar beets, sheeplambs |  |  |