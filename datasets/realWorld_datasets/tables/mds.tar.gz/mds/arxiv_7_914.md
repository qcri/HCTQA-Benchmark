| Datasets | # Samples | # Views | # Clusters |
|---|---|---|---|
| WebKB | 265 | 2 | 5 |
| BDGP | 2500 | 3 | 5 |
| MSRCV1 | 210 | 6 | 7 |
| Caltech7-2view | 1474 | 2 | 7 |
| NUS-WIDE-10 | 6251 | 5 | 10 |
| Caltech101-7 | 1474 | 6 | 7 |
| Caltech101-20 | 2386 | 6 | 20 |
| NUS-WIDE | 23953 | 5 | 31 |
| SUNRGBD | 10335 | 2 | 45 |
| YoutubeFace | 101499 | 5 | 31 |