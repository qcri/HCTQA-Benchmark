| Industry | NAICS code 1 | 1990 | 1995 | 2000 | 2001 | 2002 | 2003 |
|---|---|---|---|---|---|---|---|
| Ambulatory health care services | 621 | 2,842 | 3,768 | 4,320 | 4,462 | 4,633 | 4,776 |
| Offices of physicians | 6211 | 1,278 | 1,540 | 1,840 | 1,911 | 1,968 | 2,004 |
| Offices of dentists | 6212 | 513 | 592 | 688 | 705 | 725 | 745 |
| Offices of other health practitioners | 6213 | 276 | 395 | 438 | 457 | 486 | 501 |
| Medical and diagnostic laboratories | 6215 | 129 | 146 | 162 | 170 | 175 | 180 |
| Home health care services | 6216 | 288 | 622 | 633 | 639 | 680 | 727 |
| Hospitals | 622 | 3,513 | 3,734 | 3,954 | 4,051 | 4,160 | 4,253 |
| General medical and surgical hospitals | 6221 | 3,305 | 3,520 | 3,745 | 3,833 | 3,930 | 4,013 |
| Psychiatric and substance abuse hospitals | 6222 | 113 | 101 | 86 | 87 | 90 | 91 |
| Other hospitals. | 6223 | 95 | 112 | 123 | 132 | 140 | 148 |
| Nursing and residential care facilities | 623 | 1,856 | 2,308 | 2,583 | 2,676 | 2,743 | 2,784 |
| Nursing care facilities. | 6231 | 1,170 | 1,413 | 1,514 | 1,547 | 1,573 | 1,583 |