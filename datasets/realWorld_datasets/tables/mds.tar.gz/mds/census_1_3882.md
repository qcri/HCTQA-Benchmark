| Item | Unit | 1992 | 1993 | 1994 | 1995 | 1996 | 1997 | 1998 |
|---|---|---|---|---|---|---|---|---|
| PERIODICALS (SIC 2721) |  |  |  |  |  |  |  |  |
| Industrial data: |  |  |  |  |  |  |  |  |
| Value of shipments | Mil. dol. | 22,104 | 22,653 | 21,892 | 23,743 | 24,390 | 29,885 | (NA) |
| Value of shipments (1992 dollars) | Mil. dol. | 22,104 | 22,014 | 20,849 | 21,903 | 22,379 | (NA) | (NA) |
| Total employment | 1,000 | 115.1 | 117.1 | 117.2 | 122.0 | 120.5 | 123.6 | (NA) |
| Production workers | 1,000 | 87.2 | 90.0 | 88.0 | 89.0 | 87.6 | 88.6 | (NA) |
| Average hourly earnings | Dollar | 13.40 | 12.51 | 12.78 | 13.58 | 14.85 | 16.34 | (NA) |
| Capital expenditures | Mil. dol. | 235 | 209 | 308 | 330 | 411 | 472 | (NA) |
| Product data: |  |  |  |  |  |  |  |  |
| Value of shipments | Mil. dol. | 20,942 | 21,692 | 21,462 | 22,951 | 24,352 | (NA) | (NA) |
| Value of shipments (1992 dollars) | Mil. dol. | 20,942 | 21,080 | 20,611 | 21,173 | 21,860 | (NA) | (NA) |
| Trade data: |  |  |  |  |  |  |  |  |
| Value of imports | Mil. dol. | 134 | 194 | 209 | 222 | 217 | 204 | 217 |
| Value of exports | Mil. dol. | 731 | 737 | 788 | 825 | 819 | 864 | 864 |
| BOOK PUBLISHING (SIC 2731) |  |  |  |  |  |  |  |  |
| Industrial data: |  |  |  |  |  |  |  |  |
| Value of shipments | Mil. dol. | 16,698 | 18,616 | 19,695 | 20,484 | 21,363 | 22,648 | (NA) |
| Value of shipments (1992 dollars) | Mil. dol. | 16,698 | 16,754 | 17,038 | 17,270 | 17,730 | (NA) | (NA) |
| Total employment | 1,000 | 124.2 | 122.8 | 125.4 | 128.1 | 127.6 | 129.9 | (NA) |
| Production workers | 1,000 | 32.7 | 32.7 | 33.1 | 33.5 | 35.6 | 37.0 | (NA) |
| Average hourly earnings | Dollar | 12.51 | 12.39 | 12.63 | 13.61 | 13.27 | 16.26 | (NA) |
| Capital expenditures | Mil. dol. | 132 | 152 | 160 | 135 | 174 | 183 | (NA) |
| Product data: |  |  |  |  |  |  |  |  |
| Value of shipments | Mil. dol. | 14,761 | 16,596 | 17,229 | 18,409 | 19,114 | (NA) | (NA) |
| Value of shipments (1992 dollars) | Mil. dol. | 14,761 | 16,177 | 16,407 | 16,753 | 16,664 | (NA) | (NA) |
| Trade data: |  |  |  |  |  |  |  |  |
| Value of imports | Mil. dol. | 953 | 966 | 1,023 | 1,184 | 1,240 | 1,298 | 1,384 |
| Value of exports | Mil. dol. | 1,637 | 1,664 | 1,703 | 1,779 | 1,776 | 1,897 | 1,842 |
| COMMERCIAL PRINTING (SIC 275) |  |  |  |  |  |  |  |  |
| Industrial data: |  |  |  |  |  |  |  |  |
| Value of shipments | Mil. dol. | 56,229 | 58,173 | 60,411 | 65,101 | 67,842 | 69,824 | (NA) |
| Value of shipments (1992 dollars) | Mil. dol. | 56,229 | 56,874 | 57,852 | 59,457 | 60,555 | 61,161 | (NA) |
| Total employment | 1,000 | 567.9 | 576.4 | 582.4 | 595.4 | 605.3 | 609.6 | (NA) |
| Production workers | 1,000 | 417.7 | 426.5 | 426.2 | 437.7 | 440.7 | 442.1 | (NA) |
| Average hourly earnings | Dollar | 11.40 | 11.59 | 11.75 | 12.05 | 12.37 | 13.71 | (NA) |
| Capital expenditures | Mil. dol. | 2,298 | 2,238 | 2,498 | 2,640 | 2,659 | 2,963 | (NA) |
| Product data: |  |  |  |  |  |  |  |  |
| Value of shipments | Mil. dol. | 54,902 | 56,016 | 58,902 | 63,189 | 66,263 | (NA) | (NA) |
| Value of shipments (1992 dollars) | Mil. dol. | 54,902 | 55,577 | 56,791 | 58,277 | 59,466 | (NA) | (NA) |
| Trade data: |  |  |  |  |  |  |  |  |
| Value of imports | Mil. dol. | 442 | 505 | 581 | 756 | 748 | 823 | 909 |
| Value of exports | Mil. dol. | 1,056 | 1,201 | 1,196 | 1,195 | 1,248 | 1,293 | 1,339 |