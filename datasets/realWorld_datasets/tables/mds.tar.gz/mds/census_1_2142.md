| Program | Unit | 1980 | 1985 | 1990 | 1995 | 1996 | 1997 | 1998 | 1999 |
|---|---|---|---|---|---|---|---|---|---|
| Food Stamp: |  |  |  |  |  |  |  |  |  |
| Participants............ | Million.. | 21.1 | 19.9 | 20.1 | 26.6 | 25.5 | 22.9 | 19.8 | 18.2 |
| Federal cost............ | Mil. dol.. | 8,721 | 10,744 | 14,187 | 22,765 | 22,440 | 19,550 | 16,889 | 15,782 |
| Monthly average coupon value per recipient | Dollars.. | 34.47 | 44.99 | 58.92 | 71.27 | 73.21 | 71.27 | 71.12 | 72.33 |
| Nutrition assistance program for Puerto Rico: ¹ Federal cost. | Mil. dol. | (X) | 825 | 937 | 1,131 | 1,143 | 1,174 | 1,204 | 1,236 |
| National school lunch program (NSLP): |  |  |  |  |  |  |  |  |  |
| Free lunches served | Million | 1,671 | 1,657 | 1,662 | 2,090 | 2,128 | 2,194 | 2,197 | 2,206 |
| Reduced-price lunches served | Million | 308 | 255 | 273 | 309 | 326 | 347 | 362 | 393 |
| Children participating ² | Million | 26.6 | 23.6 | 24.1 | 25.7 | 25.9 | 26.3 | 26.6 | 27.0 |
| Federal cost. | Mil. dol. | 2,279 | 2,578 | 3,214 | 4,467 | 4,662 | 4,934 | 5,101 | 5,314 |
| School breakfast (SB): |  |  |  |  |  |  |  |  |  |
| Children participating | Million | 3.6 | 3.4 | 4.1 | 6.3 | 6.6 | 6.9 | 7.1 | 7.4 |
| Federal cost. | Mil. dol. | 288 | 379 | 596 | 1,048 | 1,119 | 1,214 | 1,272 | 1,344 |
| Special supplemental food program (WIC): Participants | Million | 1.9 | 3.1 | 4.5 | 6.9 | 7.2 | 7.4 | 7.4 | 7.3 |
| Federal cost. | Mil. dol. | 584 | 1,193 | 1,637 | 2,516 | 2,690 | 2,815 | 2,808 | 2,852 |
| Child and adult care (CC): 4 |  |  |  |  |  |  |  |  |  |
| Participants | Million | 0.7 | 1.0 | 1.5 | 2.4 | 2.4 | 2.5 | 2.6 | 2.7 |
| Federal cost. | Mil. dol. | 207 | 390 | 720 | 1,296 | 1,360 | 1,393 | 1,372 | 1,438 |
| Federal cost of commodities donated to-6 Child nutrition (NSLP, CC, SF, and SB)..... | Mil. dol. | 930 | 840 | 646 | 733 | 734 | 661 | 774 | 754 |