| Mineral | 1990 | 1995 | 1996 | 1997 | 1998, est. |
|---|---|---|---|---|---|
| Mineral production, total................. | 141,608 | 123,486 | 145,206 | 147,204 | (NA) |
| Mineral fuels, total. | 108,144 | 84,783 | 106,197 | 106,524 | 83,601 |
| Coal, total ¹........................ | 22,415 | 19,469 | 19,691 | 19,777 | 19,668 |
| Bituminous ....................... | 19,014 | 15,688 | 15,875 | 16,110 | 16,036 |
| Anthracite | 138 | 187 | 177 | 165 | 174 |
| Natural gas (wellhead) | 31,789 | 30,241 | 42,858 | 46,098 | 39,082 |
| Petroleum (crude). . . . | 53,801 | 35,006 | 43,561 | 40,576 | 24,792 |
| Uranium u3o8...... | 140 | 67 | 87 | 73 | 58 |
| Industrial minerals, total | 21,022 | 24,679 | 25,994 | 27,606 | (NA) |
| Asbestos (sales) | () | () | () | () | (°) |
| Asphalt, related bitumens (native) | 3,480 | (NA) | (NA) | (NA) | (NA) |
| Barite, primary, sold/used by producers | 16 | 10 | 15 | 16 | 15 |
| Boron minerals, sold/used by producers | 436 | 560 | 519 | 580 | (NA) |
| Bromine, sold/used by producers | 173 | 186 | 150 | 198 | 227 |
| Cement:³ |  |  |  |  |  |
| Portland | 3,683 | 4,920 | 5,310 | 5,710 | (NA) |
| Masonry | 225 | 307 | 321 | 339 | (NA) |
| Clays | 1,620 | 1,730 | 1,710 | 1,670 | (NA) |
| Diatomite | 138 | 171 | 176 | 184 | 182 |
| Feldspar 4 | 28 | 37 | 39 | 43 | 40 |
| Fluorspar, finished shipments | (*) | (*) | (*) | (*) | ( |
| Garnet (abrasive) | 7 | 4 | 6 | 6 | (NA) |
| Gemstones (estimate) | 53 | 49 | 43 | 25 | 23 |
| Gypsum, crude | 100 | 121 | 124 | 132 | 137 |
| Helium 6 | 113 | 196 | 193 | 206 | (NA) |
| Lime, sold/used by producers. | 902 | 1,100 | 1,170 | 1,200 | (NA) |
| Mica, scrap and flake, sold/used by producers. | 6 | 6 | 8 | 9 | 9 |
| Peat (sales by producers). | 19 | 17 | 19 | 18 | (NA) |
| Perlite, processed, sold/used by producers. | 17 | 22 | 21 | 23 | (NA) |
| Phosphate rock (marketable) | 1,075 | 947 | 1,060 | 1,076 | 1,131 |
| Potash (K2O equivalent). | 303 | 284 | 299 | 320 | (NA) |
| Pumice and pumicite (sales by producers) | 11 | 13 | 15 | 16 | 15 |
| Salt (common), sold/used by producers | 827 | 1,000 | 1,060 | 993 | (NA) |
| Sand and gravel, sold/used by producers | 3,686 | 4,400 | 4,500 | 4,778 | (NA) |
| Silica, special | (Z) | 1 | 1 | (NA) | (NA) |
| Sodium carbonate (natural) (soda ash) | 836 | 829 | 926 | 915 | (NA) |
| Sodium sulfate (natural) | 34 | 28 | 27 | 35 | (NA) |
| Stone | 5,822 | 6,970 | 7,410 | 8,295 | (NA) |
| Crushed and broken | 5,591 | 6,740 | 7,180 | 8,070 | (NA) |
| Dimension................... | 231 | 233 | 234 | 225 | 205 |
| Sulfur: Frasch mines (shipments) | 335 | (4) | (4) | (4) | (NA) |
| Talc and pyrophyllite, crude | 31 | 32 | 31 | (NA) | (NA) |
| Tripoli................... | 3 | 11 | 18 | 16 | (NA) |
| Vermiculite concentrate | 19 | (4) | (4) | (4) | (NA) |
| Industrial minerals, undistributed | 504 | 725 | 820 | 803 | (NA) |
| Metals, total | 12,442 | 14,024 | 13,015 | 13,074 | (NA) |
| Antimony ore and concentrate | (11) | (11) | (11) | (11) | (NA) |
| Bauxite (dried equivalent) | (11) | (11) | (11) | (11) | (NA) |
| Copper (recoverable content) | 4,311 | 5,640 | 4,610 | 4,580 | (NA) |
| Gold (recoverable content). | 3,650 | 3,950 | 4,090 | 3,850 | (NA) |
| Iron ore (gross weight) 2. | 1,741 | 1,730 | 1,770 | 1,890 | (NA) |
| Lead (recoverable content) | 491 | 359 | 459 | 460 | (NA) |
| Magnesium metal. | 433 | 476 | 455 | 400 | (NA) |
| Manganiferous ore (gross weight). | (.) | (.) | (.) | (.) | (NA) |
| Mercury 14 | (11) | (11) | (11) | (11) | (NA) |
| Molybdenum (concentrate). | 348 | 651 | 456 | (D) | (NA) |
| Palladium metal. | 22 | 22 | 26 | 50 | (NA) |
| Platinum metal. | 27 | 21 | 24 | 33 | (NA) |
| Silver (recoverable content) | 329 | 259 | 262 | 338 | (NA) |
| Titanium concentrate: Ilmenite (gross weight) | (11) | (11) | (11) | (11) | (NA) |
| Tungsten ore and concentrate | (11) | (11) | (11) | (11) | (NA) |
| Vanadium (recoverable content) | (11) | (11) | (11) | (11) | (NA) |
| Zinc mine production (recoverable content) | 847 | 756 | 674 | 860 | (NA) |
| Metals, undistributed. | 242 | 161 | 190 | 614 | (NA) |