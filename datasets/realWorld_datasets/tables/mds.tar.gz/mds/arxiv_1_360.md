| Stance: Perspective | # Generated tweets | # Generated tweets having entity mention | # Entities |
|---|---|---|---|
| pro-blacklivesmatter: whites neg actor | 30 | 27 | 41 |
| pro-blacklivesmatter: blm movement pos target | 30 | 28 | 28 |
| pro-blacklivesmatter: petition pos target | 30 | 30 | 36 |
| pro-blacklivesmatter: police neg actor | 50 | 33 | 31 |
| pro-blacklivesmatter: blm movement pos actor | 30 | 30 | 30 |
| pro-blacklivesmatter: government neg actor | 30 | 28 | 35 |
| pro-blacklivesmatter: blacks pos target | 40 | 30 | 30 |
| pro-blacklivesmatter: racism neg actor | 29 | 24 | 27 |
| pro-bluelivesmatter: community pos target | 44 | 28 | 34 |
| pro-bluelivesmatter: police pos actor | 36 | 34 | 28 |
| pro-bluelivesmatter: antifa neg actor | 29 | 27 | 30 |
| pro-bluelivesmatter: police pos target | 46 | 33 | 30 |
| pro-bluelivesmatter: blm movemen neg actor | 30 | 30 | 24 |
| pro-bluelivesmatter: republicans pos actor | 58 | 28 | 47 |
| pro-bluelivesmatter: blacks neg actor | 40 | 40 | 40 |
| pro-bluelivesmatter: democrats neg actor | 30 | 26 | 26 |
| Total | 582 | 476 | 517 |