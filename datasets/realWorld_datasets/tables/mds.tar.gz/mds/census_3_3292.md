| Kind of business | 1997 NAICS code 1 | Number of establish- ments | Receipts (mil. dol.) | Annual payroll (mil. dol.) | Paid employees (1,000) |
|---|---|---|---|---|---|
| Information: 2 |  |  |  |  |  |
| 1997 .......................... | 51 | 114,475 | 623,214 | 129,482 | 3,066.2 |
| 2002 .......................... | 51 | 137,276 | 904,614 | 189,658 | 3,845.6 |
| Publishing industries: |  |  |  |  |  |
| 1997 | 511 | 33,896 | 179,035 | 43,358 | 1,006.2 |
| 2002 |  | 32,239 | 235,300 | 64,064 | 1,132.4 |
| Motion picture and sound recording industries: |  |  |  |  |  |
| 1997 | 512 | 22,204 | 55,926 | 9,392 | 276.0 |
| 2002 | 512 | 22,831 | 76,732 | 11,696 | 334.4 |
| Broadcasting and telecommunications: |  |  |  |  |  |
| 1997 | 513 | 43,480 | 346,316 | 63,480 | 1,434.5 |
| 2002 | 513 | 57,277 | 499,061 | 83,690 | 1,740.4 |
| Information services and data processing services: 2 |  |  |  |  |  |
| 1997 | 514 | 14,895 | 41,937 | 13,252 | 349.5 |
| 2002 ............ | 514 | 24,929 | 93,521 | 30,209 | 638.5 |