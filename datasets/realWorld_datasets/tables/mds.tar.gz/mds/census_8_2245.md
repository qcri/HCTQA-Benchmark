|  | Employment status |  |  |  | Reason for job loss |  |  |
|---|---|---|---|---|---|---|---|
| Characteristic | Total (1,000) | Employed | Unem- ployed | Not in the labor force | Plant or company closed down or moved | Slack work | Position or shift abolished |
| Total 1 | 3,275 | 73.5 | 10.4 | 16.1 | 49.4 | 21.6 | 29.0 |
| 20 to 24 years old | 100 | 87.7 | 3.7 | 8.7 | 49.8 | 29.5 | 20.7 |
| 25 to 54 years old | 2,503 | 79.5 | 10.3 | 10.2 | 48.3 | 22.1 | 29.6 |
| 55 to 64 years old | 517 | 56.0 | 13.6 | 30.4 | 56.6 | 15.3 | 28.1 |
| 65 years old and over | 155 | 26.3 | 5.2 | 68.6 | 43.1 | 29.0 | 27.9 |
| Males | 1,765 | 78.9 | 9.6 | 11.5 | 47.1 | 24.0 | 28.9 |
| 20 to 24 years old | 75 | 86.6 | 4.9 | 8.4 | 43.4 | 36.1 | 20.5 |
| 25 to 54 years old | 1,331 | 85.1 | 9.1 | 5.8 | 46.2 | 24.0 | 29.8 |
| 55 to 64 years old | 279 | 62.9 | 13.3 | 23.8 | 56.3 | 17.4 | 26.3 |
| 65 years old and over | 80 | 23.6 | 10.0 | 66.4 | 33.5 | 34.6 | 31.9 |
| Females | 1,511 | 67.3 | 11.3 | 21.4 | 52.1 | 18.7 | 29.1 |
| 20 to 24 years old | 25 | (²) | (²) | (²) | (2) | (4) | (4) |
| 25 to 54 years old | 1,172 | 73.2 | 11.7 | 15.1 | 50.7 | 19.9 | 29.4 |
| 55 to 64 years old | 238 | 47.9 | 14.0 | 38.1 | 57.0 | 12.8 | 30.2 |
| 65 years old and over | 75 | 29.1 |  | 70.9 | 53.4 | 23.0 | 23.6 |
| White | 2,778 | 74.4 | 9.9 | 15.7 | 48.9 | 20.9 | 30.3 |
| Black | 363 | 72.2 | 12.8 | 15.0 | 53.2 | 26.5 | 20.3 |
| Hispanic origin 3 | 346 | 69.7 | 13.0 | 17.3 | 50.4 | 32.1 | 17.5 |