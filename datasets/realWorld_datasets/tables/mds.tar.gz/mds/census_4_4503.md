| State | Factor | Population |
|---|---|---|
| Alabama | 1.05 | 4,764,174 |
| Alaska | 0.18 | 706,048 |
| Arizona | 1.23 | 6,559,705 |
| Arkansas | 0.68 | 2,914,162 |
| California | 1.25 | 38,008,803 |
| Colorado | 1.20 | 5,214,573 |
| Connecticut | 0.88 | 3,548,671 |
| Delaware | 0.22 | 914,927 |
| District of Columbia | 0.18 | 645,108 |
| Florida | 1.12 | 19,380,887 |
| Georgia | 1.08 | 9,828,398 |
| Hawaii | 0.29 | 1,353,101 |
| Idaho | 0.36 | 1,600,046 |
| Illinois | 1.13 | 12,708,052 |
| Indiana | 1.08 | 6,495,833 |
| Iowa | 0.77 | 3,059,738 |
| Kansas | 0.73 | 2,835,666 |
| Kentucky | 1.05 | 4,315,750 |
| Louisiana | 1.05 | 4,533,806 |
| Maine | 0.39 | 1,314,170 |
| Maryland | 1.13 | 5,859,780 |
| Massachusetts | 1.06 | 6,645,793 |
| Michigan | 1.09 | 9,796,854 |
| Minnesota | 1.07 | 5,388,418 |
| Mississippi | 0.71 | 2,921,302 |
| Missouri | 1.11 | 5,947,698 |