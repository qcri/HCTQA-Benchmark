| City | Effective tax rate per $100 |  | Assessment level (percent) | Nominal rate per $100 |
|---|---|---|---|---|
|  | Rank | Rate |  |  |
| Portland, OR....... | 28 | 1.46 | 72.2 | 2.02 |
| Columbia, SC...... | 29 | 1.45 | 4.0 | 36.35 |
| Salt Lake City, UT ... | 30 | 1.43 | 99.0 | 1.45 |
| Little Rock, AR | 31 | 1.38 | 20.0 | 6.90 |
| Wilmington, DE | 32 | 1.38 | 53.1 | 2.59 |
| Wichita, KS | 33 | 1.31 | 11.5 | 11.35 |
| Minneapolis, MN | 34 | 1.27 | 86.4 | 1.47 |
| Charlotte, NC | 35 | 1.22 | 87.6 | 1.40 |
| Louisville, KY | 36 | 1.21 | 100.0 | 1.21 |
| Albuquerque, NM | 37 | 1.18 | 33.3 | 3.54 |
| Oklahoma City, OK | 38 | 1.16 | 11.0 | 10.50 |
| Kansas City, MO | 39 | 1.14 | 19.0 | 6.02 |
| Las Vegas, NV | 40 | 1.14 | 35.0 | 3.25 |
| Virginia Beach, VA... | 41 | 1.11 | 90.6 | 1.22 |
| Boston, MA ....... | 42 | 1.10 | 100.0 | 1.10 |
| Los Angeles, CA.... | 43 | 1.08 | 100.0 | 1.08 |
| Seattle, WA ....... | 44 | 1.01 | 90.6 | 1.12 |
| Washington, DC .... | 45 | 0.96 | 100.0 | 0.96 |
| New York City, NY... | 46 | 0.93 | 8.0 | 11.63 |
| Charleston, WV..... | 47 | 0.74 | 60.0 | 1.24 |
| Birmingham, AL..... | 48 | 0.70 | 10.0 | 6.95 |
| Cheyenne, WY..... | 49 | 0.61 | 9.5 | 6.47 |
| Denver, CO ........ | 50 | 0.56 | 9.2 | 6.15 |
| Honolulu, HI........ | 51 | 0.37 | 100.0 | 0.37 |
| Unweighted average . | (X) | 1.61 | 55.9 | 6.7 |
| Median .......... | (X) | 1.54 | (X) | (X) |