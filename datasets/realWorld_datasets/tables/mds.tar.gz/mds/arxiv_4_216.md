| Topics | Percentage negative sentiment review | Average sentiment | Percentage negative rating score | Average rating score |
|---|---|---|---|---|
| Advertisement | 35.66% | -0.02 | 59.60% | 2.4 |
| Bug reports | 33.67% | 0.06 | 50.90% | 2.71 |
| Quality of content | 30.48% | 0.17 | 45.40% | 2.94 |
| Negative feedback | 29.02% | 0.16 | 35.86% | 3.31 |
| Version update | 21.72% | 0.23 | 26.33% | 3.54 |
| Return on investment | 20.28% | 0.31 | 27.87% | 3.65 |
| Streaming quality | 19.78% | 0.3 | 25.62% | 3.78 |
| Feature request | 10.74% | 0.42 | 14.81% | 4.18 |
| Precision of tools | 7.35% | 0.52 | 8.10% | 4.37 |
| Accuracy of prediction | 7.27% | 0.43 | 9.98% | 4.29 |
| Impact of application | 4.42% | 0.56 | 3.23% | 4.63 |
| Up-to-dateness | 3.33% | 0.52 | 4.32% | 4.63 |
| Review credibility | 2.51% | 0.6 | 3.68% | 4.71 |
| Positive feedback | 2.51% | 0.51 | 4.08% | 4.68 |