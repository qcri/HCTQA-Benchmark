| Metropolitan area | 1997 | 1998 ¹ |
|---|---|---|
| Saginaw-Bay City-Midland, MI....... | 32,063 | 33,274 |
| Portland-Vancouver, OR-WA........ | 31,590 | 32,846 |
| Rochester, MN................ | 31,551 | 33,142 |
| Monmouth-Ocean, NJ......... | 31,510 | (NA) |
| Rochester, NY | 31,345 | 32,087 |
| Baltimore, MD | 31,317 | 32,752 |
| Springfield, IL | 31,175 | 32,608 |
| Dutchess County, NY | 31,136 | 33,581 |
| Cleveland-Lorain-Elyria, OH | 31,086 | 32,375 |
| Austin-San Marcos, TX | 31,061 | 35,488 |
| Sacramento, CA............... | 31,003 | 33,001 |
| St. Louis, MO-L............... | 30,989 | 32,263 |
| Raleigh-Durham-Chapel Hill, NC.... | 30,923 | 32,332 |
| Yolo, CA................ | 30,868 | 32,024 |
| Charlotte-Gastonia-Rock Hill, NC-SC | 30,834 | 32,884 |
| Milwaukee-Waukesha, WI | 30,689 | 32,136 |
| Lansing-East Lansing, MI | 30,672 | 30,943 |
| Bloomington-Normal, IL | 30,584 | 31,410 |
| Indianapolis, IN | 30,514 | 32,495 |
| Ventura, CA. | 30,489 | 31,962 |
| Cincinnati, OH-KY-IN. | 30,484 | 32,220 |
| Pittsburgh, PA... | 30.366 | 31,379 |
| San Diego, CA........... | 30,357 | 32,221 |
| Racine, WI | 30,346 | 31,371 |
| Dayton-Springfield, OH | 30,304 | 31,210 |
| Fort Worth-Arlington, TX | 30,054 | 31,660 |
| Richmond-Petersburg, VA | 29,986 | 31,442 |
| Nashville, TN | 29,904 | 30,685 |
| Kansas City, MO-KS | 29,809 | 31,278 |
| West Palm Beach-Boca Raton, FL... | 29,808 | 31,735 |
| Albany-Schenectady-Troy, NY...... | 29,724 | 31,086 |
| Allentown-Bethlehem-Easton, PA.... | 29,706 | 30,685 |
| Birmingham, AL.............. | 29,636 | 30,604 |
| Grand Rapids-Muskegon-Holland, MI. | 29,627 | 31,178 |
| Decatur, IL | 29,533 | 31,234 |
| Honolulu, HI............. | 29,512 | 30,248 |
| Columbus, OH................ | 29,488 | 31,180 |