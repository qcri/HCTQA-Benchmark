|  |  | 2001 1 |  |  |  |  |
|---|---|---|---|---|---|---|
| Degree and field | Graduates 1999 and 2000 (1,000) |  | Employed |  | Not employed or not FT students | Median salary 4 ($1,000) |
|  |  | In school 2 | In S&E 3 | In other |  |  |
| Bachelor's recipients................... | 758.3 | 168.4 | 171.5 | 373.8 | 44.6 | 34 |
| All science fields.................................. | 649.0 | 154.5 | 94.7 | 358.4 | 41.4 | 31 |
| Computer and information sciences. | 61.5 | (B) | 35.6 | 19.5 | 4.4 | 51 |
| Mathematical sciences | 24.4 | 4.3 | 3.8 | 14.6 | (B) | 33 |
| Life and related sciences. | 159.4 | 52.9 | 17.8 | 81.6 | 7.1 | 29 |
| Physical and related sciences | 32.2 | 10.1 | 10.6 | 9.9 | 1.6 | 34 |
| Psychology. | 152.9 | 41.0 | 11.1 | 91.2 | 9.6 | 28 |
| Social and related sciences | 218.7 | 44.2 | 15.9 | 141.7 | 17.0 | 30 |
| All engineering fields | 109.2 | 13.8 | 76.8 | 15.3 | 3.3 | 49 |
| Aerospace and related engineering | 2.2 | 0.4 | 1.3 | 0.4 | (B) | 44 |
| Chemical engineering | 10.8 | 2.2 | 6.4 | 1.7 | (B) | 50 |
| Civil and architectural engineering | 16.8 | 1.5 | 12.5 | 2.2 | (B) | 42 |
| Electrical, electronics, computer and communications engineering | 34.2 | 4.3 | 25.8 | 3.3 | (B) | 54 |
| Industrial engineering | 6.9 | (B) | 4.6 | 1.7 | (B) | 49 |
| Mechanical engineering | 25.8 | 2.7 | 18.8 | 3.6 | (B) | 48 |
| Other engineering | 12.6 | 2.3 | 7.5 | 2.2 | (B) | 45 |
| Master's recipients | 160.1 | 29.5 | 77.3 | 45.9 | 7.4 | 51 |
| All science fields . . . . . . . . . . . . . . . . . . . . . . . . . |  |  |  |  | 5.8 | 45 |
|  |  |  |  |  | (B) | 65 |
|  |  |  |  |  | (B) | 45 |
|  |  |  |  |  | (B) | 37 |
|  |  |  |  |  | (B) | 45 |
| Psychology | 33.0 | 5.8 | 9.1 | 16.1 | 2.0 | 35 |
| Social and related sciences | 27.1 | 7.1 | 5.6 | 12.8 | 1.5 | 43 |
| All engineering fields | 44.8 | 5.6 | 33.2 | 4.5 | 1.5 | 60 |
| Aerospace and related engineering | 1.2 | 0.2 | 0.8 | (B) | (B) | 62 |
| Chemical engineering | 2.0 | 0.6 | 1.2 | (B) | (B) | 58 |
| Civil and architectural engineering. | 6.3 | (B) | 5.1 | (B) | (B) | 50 |
| Electrical, electronics, computer and communications engineering | 16.4 | 1.7 | 13.0 | 1.0 | (B) | 66 |
| Industrial engineering | 3.2 | (B) | 2.4 | (B) | (B) | 62 |
| Mechanical engineering | 6.1 | 1.0 | 4.5 | (B) | (B) | 60 |
| Other engineering | 9.5 | 1.6 | 6.3 | 1.2 | (B) | 61 |