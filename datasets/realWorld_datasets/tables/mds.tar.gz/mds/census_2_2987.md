| Product description | Unit | 1995 | 1998 | 1999 | 2000 | 2001 | 2002 |
|---|---|---|---|---|---|---|---|
| INORGANIC FERTILIZERS |  |  |  |  |  |  |  |
| Ammonia, synthetic anhydrous........ | 1,000 sh. tons.... | 17,402 | 18,475 | 17,337 | 15,809 | 12,227 | 13,598 |
| Ammonium nitrate, original solution...... | 1,000 sh. tons..... | 8,489 | 9,079 | 7,630 | 7,979 | 6,431 | 6,973 |
| Ammonium sulfate....... | 1,000 sh. tons.... | 2,647 | 2,787 | 2,875 | 2,808 | 2,588 | 2,848 |
| Urea (100%) | 1,000 sh. tons. | 8,117 | 8,865 | 8,907 | 7,682 | 6,702 | 7,758 |
| Nitric acid (100%)............... | 1,000 sh. tons. | 8,839 | 9,285 | 8,945 | 8,708 | 7,074 | 7,651 |
| Phosphoric acid (100% P2O5) | 1,000 sh. tons. | 13,134 | 13,891 | 13,708 | 12,492 | 11,546 | 11,846 |
| Sulfuric acid, gross (100%) | 1,000 sh. tons. | 47,519 | 48,513 | 44,756 | 43,643 | 40,064 | 39,196 |
| Superphosphates and other fertilizer materials (100% P2O5) | 1,000 sh. tons. | 10,364 | 10,260 | 9,133 | 8,899 | 8,109 | 8,545 |
| INORGANIC CHEMICALS |  |  |  |  |  |  |  |
| Chlorine gas | 1,000 metric tons. | 12,395 | 11,650 | 12,114 | 14,000 | 11,489 | 11,684 |
| Sodium hydroxide, total liquid. | 1,000 metric tons. | 11,408 | 11,896 | 11,974 | 11,523 | 9,813 | 9,461 |
| Potassium hydoxide liquid | 1,000 metric tons. | (D) | 450 | 430 | 539 | 465 | 470 |
| Finished sodium bicarbonate | 1,000 metric tons. | 520 | 493 | 505 | 536 | 513 | 535 |
| Titanium dioxide, composite and pure... | 1,000 metric tons. | 1,382 | 1,323 | 1,355 | 1,547 | 1,327 | 1,409 |
| Hydrochloric acid.................. | 1,000 metric tons. | 3,904 | 4,226 | 4,191 | 4,717 | 3,970 | 4,038 |
| Aluminum oxide. | 1,000 metric tons. | 4,764 | 4,537 | 4,016 | (D) | 2,863 | (D) |
| Aluminum sulfate (commercial).... | 1,000 metric tons. | 1,144 | 1,058 | 1,052 | 1,076 | 1,020 | 1,054 |
| Sodium chlorate. | 1,000 metric tons.. | 617 | 707 | 742 | 940 | 792 | 721 |
| Sodium phosphate tripoly | 1,000 metric tons. | (D) | 205 | (D) | (D) | (D) | (D) |
| Sodium silicats | 1,000 metric tons. | 1,203 | 1,097 | 992 | 1,136 | 1,070 | 1,054 |
| Sodium metasilicates | 1,000 metric tons. | 93 | 70 | 63 | 72 | 63 | 58 |
| Sodium sulfate | 1,000 metric tons. | (D) | 571 | 599 | 509 | 76 | 74 |
| Carbon activated | 1,000 metric tons. | 156 | 150 | 151 | 166 | (S) | (D) |
| Hydrogen peroxide.................. | 1,000 metric tons. | 355 | 324 | 342 | 1,083 | (S) | (S) |
| Phosphorous, oxychloride and trichlorde... | 1,000 metric tons. | 226 | (D) | 163 | (D) | (D) | (D) |