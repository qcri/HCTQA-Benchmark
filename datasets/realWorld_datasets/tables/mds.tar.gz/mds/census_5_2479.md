|  |  | Home equity lines of credit |  |  | Traditional home equity loans |  |  |
|---|---|---|---|---|---|---|---|
| Year | Total | All lenders | Commercial banks | Other sources | All lenders | Commercial banks | Other sources |
| 1990 | 258 | 105 | 61 | 44 | 153 | 54 | 99 |
| 1992 | 258 | 114 | 73 | 41 | 144 | 50 | 94 |
| 1993 | 261 | 110 | 73 | 37 | 151 | 49 | 102 |
| 1994 | 274 | 116 | 76 | 40 | 158 | 54 | 104 |
| 1995 | 299 | 123 | 79 | 44 | 176 | 61 | 115 |
| 1996 | 347 | 132 | 85 | 47 | 215 | 69 | 146 |
| 1997 | 420 | 152 | 98 | 54 | 268 | 76 | 192 |
| 1998 | 470 | 153 | 96 | 57 | 317 | 80 | 237 |