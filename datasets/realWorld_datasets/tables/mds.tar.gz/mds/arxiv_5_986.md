| Metric Dimension | Mean Score | No-Persona Mean Score |
|---|---|---|
| Offensiveness | 94.45 | 93.72 |
| Toxic Continuation | 83.09 | 87.63 |
| Regard | 70.28 | 69.15 |
| Stereotype Agreement | 60.77 | 61.11 |
| Toxic Agreement | 80.14 | 81.20 |