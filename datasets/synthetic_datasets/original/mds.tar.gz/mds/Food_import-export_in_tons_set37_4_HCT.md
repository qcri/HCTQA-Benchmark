|  |  | Import | Export |
|---|---|---|---|
| Cereals | Corn | 50.00 | 960.00 |
|  | Oats | 394.00 | 225.00 |
| Dairy | Cheese | 893.00 | 496.00 |
|  | Cream | 124.00 | 294.00 |
|  | Yoghurt | 88.00 | 135.00 |
| Meat | Camel | 969.00 | 819.00 |
|  | Chicken | 284.00 | 337.00 |
|  | Pork | 209.00 | 696.00 |