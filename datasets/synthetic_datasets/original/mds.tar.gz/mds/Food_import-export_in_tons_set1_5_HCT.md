|  |  | Import | Export |
|---|---|---|---|
| Beverage | Coffee | 145.00 | 95.00 |
|  | Soda | 949.00 | 984.00 |
|  | Tea | 796.00 | 193.00 |
| Cereals | Rice | 795.00 | 994.00 |
|  | Seeds | 495.00 | 364.00 |
|  | Wheat | 146.00 | 701.00 |
| Dairy | Butter | 67.00 | 50.00 |
|  | Cheese | 727.00 | 559.00 |
|  | Cream | 809.00 | 593.00 |