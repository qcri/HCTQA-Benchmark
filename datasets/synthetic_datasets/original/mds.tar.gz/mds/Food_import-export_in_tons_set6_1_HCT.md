|  |  | Import | Export |
|---|---|---|---|
| Beverage | Coffee | 100.00 | 271.00 |
|  | Soda | 729.00 | 87.00 |
|  | Tea | 697.00 | 777.00 |
| Cereals | Seeds | 681.00 | 975.00 |
|  | Wheat | 921.00 | 966.00 |
| Dairy | Butter | 736.00 | 242.00 |
|  | Cream | 922.00 | 686.00 |
|  | Milk | 646.00 | 456.00 |