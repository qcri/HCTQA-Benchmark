|  |  | Import | Export |
|---|---|---|---|
| Cereals | Seeds | 126.00 | 914.00 |
|  | Soybeans | 14.00 | 34.00 |
|  | Wheat | 896.00 | 117.00 |
| Dairy | Cheese | 367.00 | 249.00 |
|  | Yoghurt | 337.00 | 807.00 |
| Meat | Camel | 636.00 | 391.00 |
|  | Duck | 46.00 | 160.00 |
|  | Pork | 546.00 | 530.00 |