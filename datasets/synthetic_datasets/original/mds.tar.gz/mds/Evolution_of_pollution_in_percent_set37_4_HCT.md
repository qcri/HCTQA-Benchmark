|  |  | Michigan |  |  | Minnesota |  |
|---|---|---|---|---|---|---|
|  |  | Detroit | Flint | Port Huron | Minneapolis | Rochester |
| Air | Light | -16.24 | -15.84 | -23.06 | 66.23 | -50.33 |
|  | Noise | -93.84 | -36.49 | 20.71 | 87.88 | 77.26 |
|  | Thermal | -70.28 | -2.99 | -12.00 | 24.98 | 4.38 |
| Soil | Industrial | -26.80 | 34.31 | -38.46 | -18.14 | -73.02 |
|  | Inferior Irrigation | -70.06 | 93.99 | -77.87 | -34.44 | -61.51 |
|  | Inorganic Fertilizers | -56.43 | -53.32 | -59.56 | 73.08 | -50.49 |
|  | Solid Waste | -38.71 | 15.62 | -31.46 | -84.55 | -46.78 |
| Water | Chemical | -51.51 | 12.59 | 65.03 | 48.93 | -89.00 |
|  | Groundwater | -89.72 | -11.11 | 68.05 | 67.23 | -61.13 |
|  | Oxygen-depletion | 64.14 | 90.62 | -17.23 | 49.01 | -10.45 |