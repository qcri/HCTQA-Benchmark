|  |  | Culture |  |  | Service |  |
|---|---|---|---|---|---|---|
|  |  | Concert | Museum | Theatre | Administration | Hospital |
| Q3 | August | 60.00 | 89.00 | 59.00 | 65.00 | 85.00 |
|  | July | 74.00 | 82.00 | 13.00 | 31.00 | 57.00 |
| Q4 | December | 98.00 | 90.00 | 11.00 | 37.00 | 44.00 |
|  | November | 1.00 | 24.00 | 19.00 | 3.00 | 97.00 |
|  | October | 69.00 | 14.00 | 51.00 | 73.00 | 0.00 |