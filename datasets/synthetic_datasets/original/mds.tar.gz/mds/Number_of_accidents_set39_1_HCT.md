|  |  | Male | Female |
|---|---|---|---|
| Fire | Serious | 27.00 | 17.00 |
|  | Fatal | 68.00 | 94.00 |
| Traffic | Serious | 36.00 | 39.00 |
|  | Fatal | 10.00 | 100.00 |
| Drowning | Serious | 86.00 | 91.00 |
|  | Fatal | 25.00 | 65.00 |