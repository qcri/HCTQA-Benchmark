|  | 2015/2016 |  | 2016/2017 |  | 2017/2018 |  | 2018/2019 |  |
|---|---|---|---|---|---|---|---|---|
|  | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari |
| Government | 24 | 17 | 31 | 80 | 22 | 54 | 94 | 60 |
| Private | 25 | 4 | 38 | 18 | 42 | 95 | 48 | 64 |