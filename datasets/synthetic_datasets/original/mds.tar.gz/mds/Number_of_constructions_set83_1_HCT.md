|  |  | Production |  | Residential |  |
|---|---|---|---|---|---|
|  |  | Factory | Workshop | Apartment | House |
| Q3 | August | 78.00 | 84.00 | 90.00 | 3.00 |
|  | July | 79.00 | 66.00 | 76.00 | 91.00 |
|  | Minimum | 78.00 | 66.00 | 76.00 | 3.00 |
| Q4 | December | 49.00 | 38.00 | 26.00 | 99.00 |
|  | November | 70.00 | 54.00 | 2.00 | 68.00 |
|  | Minimum | 49.00 | 38.00 | 2.00 | 68.00 |
| Minimum |  | 49.00 | 38.00 | 2.00 | 3.00 |