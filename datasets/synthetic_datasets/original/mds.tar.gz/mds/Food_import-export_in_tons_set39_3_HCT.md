|  |  | Import | Export |
|---|---|---|---|
| Beverage | Coffee | 173.00 | 521.00 |
|  | Tea | 399.00 | 884.00 |
| Cereals | Corn | 522.00 | 483.00 |
|  | Oats | 756.00 | 304.00 |
|  | Rice | 916.00 | 496.00 |
| Dairy | Butter | 586.00 | 992.00 |
|  | Cheese | 624.00 | 338.00 |
|  | Cream | 328.00 | 383.00 |