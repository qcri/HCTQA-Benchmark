|  |  | California |  |  | Florida |  |  | Average |
|---|---|---|---|---|---|---|---|---|
|  |  | Malibu | San Francisco | Average | Fort Lauderdale | Tampa | Average |  |
| Soil | Industrial | -70.58 | -32.92 | -51.75 | 22.01 | -0.07 | 10.97 | -20.39 |
|  | Inferior Irrigation | -48.27 | 3.38 | -22.45 | -60.31 | -10.56 | -35.44 | -28.94 |
|  | Solid Waste | 43.11 | -81.29 | -19.09 | 67.09 | -78.49 | -5.70 | -12.39 |
| Water | Groundwater | -58.04 | 74.11 | 8.04 | -64.28 | 10.74 | -26.77 | -9.37 |
|  | Oxygen-depletion | -1.89 | 76.71 | 37.41 | 48.41 | -55.95 | -3.77 | 16.82 |