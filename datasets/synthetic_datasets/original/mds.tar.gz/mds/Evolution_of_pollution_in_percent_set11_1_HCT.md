|  |  | Georgia |  | Illinois |  |  |
|---|---|---|---|---|---|---|
|  |  | Columbus | Washington | Champaign | Chicago | Springfield |
| Soil | Industrial | -49.10 | 91.67 | -62.35 | 16.92 | -58.58 |
|  | Inferior Irrigation | 58.09 | -18.44 | 27.14 | -96.37 | -42.16 |
|  | Inorganic Fertilizers | -90.61 | -73.47 | 74.07 | 6.82 | -57.38 |
|  | Solid Waste | 92.03 | -84.62 | 27.53 | -81.18 | -65.79 |
|  | Urban Activities | 62.19 | -63.55 | 0.58 | -62.27 | 35.77 |
|  | Average | 14.52 | -29.68 | 13.39 | -43.22 | -37.63 |
| Water | Groundwater | -41.67 | -73.44 | 33.59 | -51.34 | -82.76 |
|  | Oxygen-depletion | 3.02 | -84.15 | -14.56 | -62.31 | -38.05 |
|  | Average | -19.32 | -78.80 | 9.52 | -56.83 | -60.41 |
| Average |  | 4.85 | -43.71 | 12.29 | -47.10 | -44.14 |