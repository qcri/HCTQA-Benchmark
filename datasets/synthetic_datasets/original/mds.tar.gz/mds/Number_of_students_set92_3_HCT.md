|  | 2020/2021 |  |  | 2021/2022 |  |  | 2022/2023 |  |  | Total |
|---|---|---|---|---|---|---|---|---|---|---|
|  | Qatari | Non-Qatari | Total | Qatari | Non-Qatari | Total | Qatari | Non-Qatari | Total |  |
| Government | 71 | 1 | 72 | 38 | 31 | 69 | 63 | 34 | 97 | 238 |
| Private | 22 | 49 | 71 | 33 | 19 | 52 | 2 | 90 | 92 | 215 |