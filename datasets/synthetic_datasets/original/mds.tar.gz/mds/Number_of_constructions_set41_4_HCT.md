|  |  |  |  | Culture |  |  | Production |  |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  | Concert | Museum | Theatre | Factory | Workshop |
| Q2 | June | Florida | Fort Lauderdale | 35.00 | 4.00 | 100.00 | 44.00 | 74.00 |
|  |  |  | Tampa | 19.00 | 85.00 | 31.00 | 1.00 | 98.00 |
|  | May | Florida | Fort Lauderdale | 99.00 | 78.00 | 95.00 | 7.00 | 59.00 |
|  |  |  | Tampa | 11.00 | 70.00 | 76.00 | 94.00 | 71.00 |
| Q3 | August | Florida | Fort Lauderdale | 88.00 | 68.00 | 96.00 | 83.00 | 25.00 |
|  |  |  | Tampa | 22.00 | 79.00 | 13.00 | 86.00 | 90.00 |
|  | September | Florida | Fort Lauderdale | 43.00 | 32.00 | 27.00 | 57.00 | 36.00 |
|  |  |  | Tampa | 8.00 | 75.00 | 50.00 | 69.00 | 49.00 |