|  |  | Massachusetts |  |  | Michigan |  |
|---|---|---|---|---|---|---|
|  |  | Boston | Cambridge | Lenox | Detroit | Flint |
| Air | Light | -8.11 | -75.15 | -69.71 | 77.81 | -16.75 |
|  | Thermal | 76.44 | -2.60 | 19.58 | -11.32 | 59.48 |
| Soil | Industrial | 79.88 | -46.97 | -71.12 | 41.46 | 69.59 |
|  | Inferior Irrigation | 95.97 | -13.36 | 50.13 | -15.28 | -82.63 |
|  | Inorganic Fertilizers | -75.68 | 83.30 | 69.25 | -43.89 | 64.88 |