|  |  | Male | Female |
|---|---|---|---|
| Fire | Fatal | 29.00 | 46.00 |
|  | Average | 29.00 | 46.00 |
| Traffic | Fatal | 24.00 | 52.00 |
|  | Average | 24.00 | 52.00 |
| Average |  | 26.50 | 49.00 |