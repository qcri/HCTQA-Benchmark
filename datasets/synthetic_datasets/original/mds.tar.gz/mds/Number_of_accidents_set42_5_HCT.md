|  |  | Male | Female |
|---|---|---|---|
| Slight | Traffic | 52.00 | 97.00 |
|  | Drowning | 53.00 | 13.00 |
| Serious | Traffic | 39.00 | 51.00 |
|  | Drowning | 28.00 | 19.00 |