|  |  |  |  | Culture |  | Production |  | Service |  |
|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  | Concert | Theatre | Factory | Workshop | Administration | Hospital |
| Q2 | June | Florida | Fort Lauderdale | 74.00 | 66.00 | 59.00 | 48.00 | 29.00 | 39.00 |
|  |  | Georgia | Washington | 88.00 | 34.00 | 87.00 | 77.00 | 46.00 | 68.00 |
|  | May | Florida | Fort Lauderdale | 91.00 | 13.00 | 17.00 | 38.00 | 93.00 | 60.00 |
|  |  | Georgia | Washington | 19.00 | 0.00 | 52.00 | 92.00 | 5.00 | 11.00 |
| Q3 | August | Florida | Fort Lauderdale | 100.00 | 81.00 | 98.00 | 85.00 | 69.00 | 70.00 |
|  |  | Georgia | Washington | 7.00 | 10.00 | 84.00 | 2.00 | 15.00 | 26.00 |
|  | July | Florida | Fort Lauderdale | 27.00 | 8.00 | 12.00 | 45.00 | 41.00 | 79.00 |
|  |  | Georgia | Washington | 53.00 | 44.00 | 89.00 | 23.00 | 83.00 | 94.00 |
|  | September | Florida | Fort Lauderdale | 3.00 | 64.00 | 1.00 | 56.00 | 67.00 | 90.00 |
|  |  | Georgia | Washington | 50.00 | 73.00 | 96.00 | 63.00 | 16.00 | 51.00 |
| Q4 | December | Florida | Fort Lauderdale | 97.00 | 35.00 | 14.00 | 9.00 | 72.00 | 86.00 |
|  |  | Georgia | Washington | 21.00 | 6.00 | 20.00 | 61.00 | 22.00 | 18.00 |
|  | November | Florida | Fort Lauderdale | 57.00 | 65.00 | 78.00 | 80.00 | 33.00 | 62.00 |
|  |  | Georgia | Washington | 71.00 | 4.00 | 58.00 | 37.00 | 25.00 | 31.00 |
|  | October | Florida | Fort Lauderdale | 32.00 | 40.00 | 36.00 | 28.00 | 24.00 | 82.00 |
|  |  | Georgia | Washington | 43.00 | 49.00 | 95.00 | 76.00 | 99.00 | 75.00 |