|  |  | Male | Female |
|---|---|---|---|
| Traffic | Slight | 65.00 | 46.00 |
|  | Serious | 80.00 | 27.00 |
| Drowning | Slight | 83.00 | 66.00 |
|  | Serious | 25.00 | 40.00 |