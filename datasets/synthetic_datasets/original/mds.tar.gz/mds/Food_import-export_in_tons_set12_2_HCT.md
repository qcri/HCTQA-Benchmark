|  |  | Import | Export |
|---|---|---|---|
| Cereals | Oats | 209.00 | 651.00 |
|  | Rice | 972.00 | 480.00 |
|  | Average | 590.50 | 565.50 |
| Dairy | Cheese | 119.00 | 179.00 |
|  | Cream | 462.00 | 194.00 |
|  | Average | 290.50 | 186.50 |
| Meat | Chicken | 797.00 | 69.00 |
|  | Pork | 946.00 | 444.00 |
|  | Average | 871.50 | 256.50 |
| Average |  | 584.17 | 336.17 |