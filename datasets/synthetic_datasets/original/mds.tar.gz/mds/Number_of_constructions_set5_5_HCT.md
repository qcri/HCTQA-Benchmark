|  |  | Culture |  |  | Production |  |
|---|---|---|---|---|---|---|
|  |  | Concert | Museum | Theatre | Factory | Workshop |
| Q3 | August | 80.00 | 95.00 | 16.00 | 77.00 | 96.00 |
|  | September | 76.00 | 92.00 | 87.00 | 68.00 | 81.00 |
| Q4 | November | 35.00 | 86.00 | 74.00 | 32.00 | 85.00 |
|  | October | 11.00 | 79.00 | 24.00 | 33.00 | 93.00 |