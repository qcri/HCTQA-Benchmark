|  |  | Culture |  | Production |  |
|---|---|---|---|---|---|
|  |  | Museum | Theatre | Factory | Workshop |
| Q3 | August | 36.00 | 9.00 | 29.00 | 14.00 |
|  | July | 40.00 | 10.00 | 5.00 | 81.00 |
|  | September | 50.00 | 16.00 | 28.00 | 78.00 |
| Q4 | December | 48.00 | 6.00 | 69.00 | 39.00 |
|  | November | 22.00 | 63.00 | 0.00 | 26.00 |
|  | October | 65.00 | 75.00 | 80.00 | 41.00 |