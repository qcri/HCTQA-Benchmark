|  |  | 2020/2021 |  | 2021/2022 |  |
|---|---|---|---|---|---|
|  |  | Qatari | Non-Qatari | Qatari | Non-Qatari |
| Government | Male | 2 | 25 | 12 | 24 |
|  | Female | 86 | 3 | 48 | 78 |
|  | Total | 88 | 28 | 60 | 102 |
| Private | Male | 42 | 27 | 53 | 10 |
|  | Female | 40 | 63 | 31 | 38 |
|  | Total | 82 | 90 | 84 | 48 |
| Total |  | 170 | 118 | 144 | 150 |