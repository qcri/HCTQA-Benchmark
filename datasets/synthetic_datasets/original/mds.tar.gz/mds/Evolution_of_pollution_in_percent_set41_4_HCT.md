|  |  | Minnesota |  | Nevada |  |
|---|---|---|---|---|---|
|  |  | Hastings | Minneapolis | Las Vegas | Reno |
| Soil | Inferior Irrigation | -94.36 | 67.25 | 14.02 | 1.20 |
|  | Solid Waste | -79.09 | -44.34 | 80.89 | 5.45 |
|  | Urban Activities | 11.74 | 19.20 | -58.90 | -23.60 |
| Water | Chemical | 98.91 | -68.81 | 24.00 | -38.72 |
|  | Groundwater | -64.38 | -89.20 | -34.26 | -1.69 |