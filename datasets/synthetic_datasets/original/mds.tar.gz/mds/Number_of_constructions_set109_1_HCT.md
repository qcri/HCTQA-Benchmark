|  |  |  |  | Culture |  |  | Production |  | Residential |  |
|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  | Concert | Museum | Theatre | Factory | Workshop | Apartment | House |
| Q3 | August | Georgia | Albany | 95.00 | 54.00 | 69.00 | 40.00 | 92.00 | 8.00 | 2.00 |
|  | July | Georgia | Albany | 90.00 | 83.00 | 94.00 | 42.00 | 84.00 | 31.00 | 37.00 |
| Q4 | November | Georgia | Albany | 27.00 | 80.00 | 33.00 | 1.00 | 11.00 | 58.00 | 45.00 |
|  | October | Georgia | Albany | 85.00 | 49.00 | 26.00 | 60.00 | 13.00 | 82.00 | 64.00 |