|  |  |  |  | Production |  |  | Residential |  |  | Minimum |
|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  | Factory | Workshop | Minimum | Apartment | Hotel | Minimum |  |
| Q2 | April | Nevada | Reno | 41.00 | 54.00 | 41.00 | 42.00 | 44.00 | 42.00 | 41.00 |
|  | June | Nevada | Reno | 53.00 | 74.00 | 53.00 | 88.00 | 73.00 | 73.00 | 53.00 |
|  | May | Nevada | Reno | 62.00 | 30.00 | 30.00 | 6.00 | 81.00 | 6.00 | 6.00 |
| Q3 | August | Nevada | Reno | 90.00 | 92.00 | 90.00 | 85.00 | 57.00 | 57.00 | 57.00 |
|  | July | Nevada | Reno | 38.00 | 76.00 | 38.00 | 3.00 | 99.00 | 3.00 | 3.00 |
|  | September | Nevada | Reno | 71.00 | 7.00 | 7.00 | 96.00 | 16.00 | 16.00 | 7.00 |
| Q4 | November | Nevada | Reno | 17.00 | 22.00 | 17.00 | 66.00 | 78.00 | 66.00 | 17.00 |
|  | October | Nevada | Reno | 36.00 | 14.00 | 14.00 | 50.00 | 1.00 | 1.00 | 1.00 |