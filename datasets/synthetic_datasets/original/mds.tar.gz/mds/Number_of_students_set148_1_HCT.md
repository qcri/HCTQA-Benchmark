|  |  | 2019/2020 |  |  |  |  |  |  |  | 2020/2021 |  |  |  |  |  |  |  |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  |
|  |  | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari |
| Government | Male | 91 | 3 | 42 | 37 | 69 | 55 | 66 | 49 | 47 | 13 | 33 | 54 | 2 | 40 | 93 | 67 |
|  | Female | 10 | 53 | 73 | 71 | 44 | 46 | 48 | 96 | 45 | 87 | 77 | 98 | 16 | 56 | 9 | 95 |
| Private | Male | 35 | 52 | 68 | 20 | 14 | 43 | 81 | 15 | 85 | 27 | 12 | 79 | 89 | 92 | 32 | 97 |
|  | Female | 38 | 86 | 21 | 78 | 11 | 17 | 28 | 99 | 63 | 23 | 29 | 22 | 30 | 59 | 58 | 94 |