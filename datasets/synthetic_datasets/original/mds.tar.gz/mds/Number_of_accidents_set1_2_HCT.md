|  | Male | Female |
|---|---|---|
| Fire | 14.00 | 83.00 |
| Traffic | 26.00 | 33.00 |
| Drowning | 31.00 | 96.00 |