|  |  | Male | Female | Average |
|---|---|---|---|---|
| Fire | Fatal | 83.00 | 98.00 | 90.50 |
| Traffic | Fatal | 35.00 | 67.00 | 51.00 |
| Drowning | Fatal | 87.00 | 88.00 | 87.50 |