|  |  |  |  | Culture |  |  | Production |  |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  | Concert | Museum | Theatre | Factory | Workshop |
| Q2 | April | Maryland | Baltimore | 100.00 | 25.00 | 37.00 | 34.00 | 81.00 |
|  |  |  | Columbia | 98.00 | 86.00 | 35.00 | 77.00 | 21.00 |
|  |  | Massachusetts | Boston | 93.00 | 62.00 | 91.00 | 69.00 | 65.00 |
|  |  |  | Cambridge | 70.00 | 41.00 | 95.00 | 63.00 | 76.00 |
|  | June | Maryland | Baltimore | 12.00 | 92.00 | 6.00 | 48.00 | 11.00 |
|  |  |  | Columbia | 43.00 | 82.00 | 80.00 | 26.00 | 31.00 |
|  |  | Massachusetts | Boston | 74.00 | 60.00 | 5.00 | 24.00 | 39.00 |
|  |  |  | Cambridge | 13.00 | 90.00 | 16.00 | 36.00 | 99.00 |
|  | May | Maryland | Baltimore | 38.00 | 33.00 | 68.00 | 45.00 | 57.00 |
|  |  |  | Columbia | 19.00 | 71.00 | 32.00 | 29.00 | 1.00 |
|  |  | Massachusetts | Boston | 75.00 | 83.00 | 84.00 | 64.00 | 4.00 |
|  |  |  | Cambridge | 50.00 | 44.00 | 58.00 | 97.00 | 51.00 |
| Q3 | August | Maryland | Baltimore | 66.00 | 56.00 | 79.00 | 54.00 | 42.00 |
|  |  |  | Columbia | 52.00 | 94.00 | 23.00 | 7.00 | 55.00 |
|  |  | Massachusetts | Boston | 53.00 | 22.00 | 85.00 | 2.00 | 96.00 |
|  |  |  | Cambridge | 27.00 | 89.00 | 14.00 | 10.00 | 0.00 |
|  | September | Maryland | Baltimore | 73.00 | 59.00 | 61.00 | 49.00 | 72.00 |
|  |  |  | Columbia | 8.00 | 9.00 | 78.00 | 46.00 | 40.00 |
|  |  | Massachusetts | Boston | 47.00 | 15.00 | 88.00 | 28.00 | 87.00 |
|  |  |  | Cambridge | 17.00 | 18.00 | 20.00 | 67.00 | 3.00 |