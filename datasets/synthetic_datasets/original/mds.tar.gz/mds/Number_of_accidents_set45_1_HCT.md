|  |  | Male | Female |
|---|---|---|---|
| Fire | Slight | 39.00 | 86.00 |
|  | Serious | 94.00 | 38.00 |
|  | Average | 66.50 | 62.00 |
| Traffic | Slight | 98.00 | 13.00 |
|  | Serious | 88.00 | 56.00 |
|  | Average | 93.00 | 34.50 |
| Average |  | 79.75 | 48.25 |