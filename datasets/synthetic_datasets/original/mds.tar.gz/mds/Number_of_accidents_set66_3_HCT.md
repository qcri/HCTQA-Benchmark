|  |  | Male | Female | Average |
|---|---|---|---|---|
| Fire | Fatal | 21.00 | 11.00 | 16.00 |
|  | Average | 21.00 | 11.00 | 16.00 |
| Traffic | Fatal | 82.00 | 80.00 | 81.00 |
|  | Average | 82.00 | 80.00 | 81.00 |
| Average |  | 51.50 | 45.50 | 48.50 |