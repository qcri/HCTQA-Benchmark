|  |  | 2019/2020 |  | 2020/2021 |  | 2021/2022 |  | 2022/2023 |  |
|---|---|---|---|---|---|---|---|---|---|
|  |  | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari | Qatari | Non-Qatari |
| Male | Government | 50 | 44 | 1 | 45 | 86 | 4 | 46 | 97 |
|  | Private | 7 | 76 | 54 | 26 | 58 | 72 | 8 | 68 |
| Female | Government | 100 | 56 | 89 | 85 | 25 | 91 | 93 | 63 |
|  | Private | 87 | 40 | 0 | 21 | 12 | 15 | 49 | 62 |