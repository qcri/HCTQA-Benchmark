|  |  | Minnesota |  | Nevada |  |
|---|---|---|---|---|---|
|  |  | Minneapolis | Rochester | Boulder City | Las Vegas |
| Soil | Inferior Irrigation | 24.20 | -77.62 | -22.72 | 17.28 |
|  | Solid Waste | -70.47 | 88.49 | 76.68 | 55.77 |
| Water | Groundwater | 69.19 | 18.71 | -45.05 | 3.62 |
|  | Oxygen-depletion | 64.09 | 25.60 | 36.99 | -37.05 |
|  | Surface water | 60.28 | -39.71 | -45.17 | -72.14 |