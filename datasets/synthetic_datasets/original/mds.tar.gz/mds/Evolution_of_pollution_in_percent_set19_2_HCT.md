|  |  | Massachusetts |  |  | Michigan |  |  | Minnesota |  |  |  | Average |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  | Boston | Cambridge | Average | Detroit | Flint | Average | Hastings | Minneapolis | Rochester | Average |  |
| Soil | Industrial | 91.41 | -98.03 | -3.31 | -91.98 | -3.58 | -47.78 | 89.80 | 75.32 | -2.69 | 54.14 | 8.61 |
|  | Inorganic Fertilizers | -87.83 | -45.05 | -66.44 | 7.72 | -66.97 | -29.62 | 21.66 | 3.13 | 72.89 | 32.56 | -13.49 |
| Water | Oxygen-depletion | -27.36 | -32.18 | -29.77 | -67.62 | 6.36 | -30.63 | -15.87 | -83.62 | 36.30 | -21.06 | -26.28 |
|  | Surface water | 48.04 | 71.39 | 59.72 | -45.28 | -65.56 | -55.42 | 25.14 | -8.36 | 69.14 | 28.64 | 13.50 |