|  |  |  |  | Culture |  |  | Service |  |  |  | Minimum |
|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  | Concert | Theatre | Minimum | Administration | Hospital | School | Minimum |  |
| Q1 | February | Michigan | Detroit | 45.00 | 27.00 | 27.00 | 65.00 | 6.00 | 41.00 | 6.00 | 6.00 |
|  | January | Michigan | Detroit | 85.00 | 48.00 | 48.00 | 19.00 | 92.00 | 2.00 | 2.00 | 2.00 |
|  | March | Michigan | Detroit | 76.00 | 79.00 | 76.00 | 55.00 | 56.00 | 64.00 | 55.00 | 55.00 |
| Q2 | June | Michigan | Detroit | 37.00 | 100.00 | 37.00 | 16.00 | 53.00 | 87.00 | 16.00 | 16.00 |
|  | May | Michigan | Detroit | 4.00 | 89.00 | 4.00 | 93.00 | 35.00 | 32.00 | 32.00 | 4.00 |
| Q3 | August | Michigan | Detroit | 5.00 | 26.00 | 5.00 | 15.00 | 58.00 | 49.00 | 15.00 | 5.00 |
|  | July | Michigan | Detroit | 18.00 | 25.00 | 18.00 | 40.00 | 9.00 | 38.00 | 9.00 | 9.00 |
|  | September | Michigan | Detroit | 61.00 | 13.00 | 13.00 | 82.00 | 90.00 | 75.00 | 75.00 | 13.00 |