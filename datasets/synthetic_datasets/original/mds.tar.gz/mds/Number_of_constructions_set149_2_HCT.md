|  |  |  |  | Production |  | Residential |  |  |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  | Factory | Workshop | Apartment | Hotel | House |
| Q1 | February | Massachusetts | Lenox | 36.00 | 35.00 | 74.00 | 30.00 | 97.00 |
|  |  | Michigan | Flint | 75.00 | 11.00 | 95.00 | 14.00 | 44.00 |
|  | January | Massachusetts | Lenox | 23.00 | 83.00 | 9.00 | 34.00 | 25.00 |
|  |  | Michigan | Flint | 26.00 | 79.00 | 98.00 | 40.00 | 38.00 |
|  | March | Massachusetts | Lenox | 20.00 | 47.00 | 1.00 | 100.00 | 60.00 |
|  |  | Michigan | Flint | 5.00 | 52.00 | 22.00 | 93.00 | 55.00 |
| Q2 | April | Massachusetts | Lenox | 85.00 | 24.00 | 16.00 | 64.00 | 2.00 |
|  |  | Michigan | Flint | 80.00 | 6.00 | 90.00 | 18.00 | 51.00 |
|  | May | Massachusetts | Lenox | 58.00 | 59.00 | 63.00 | 99.00 | 67.00 |
|  |  | Michigan | Flint | 91.00 | 21.00 | 10.00 | 77.00 | 37.00 |