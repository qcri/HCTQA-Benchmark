|  |  | Import | Export |
|---|---|---|---|
| Beverage | Juice | 555.00 | 25.00 |
|  | Soda | 840.00 | 971.00 |
| Dairy | Cheese | 373.00 | 363.00 |
|  | Cream | 93.00 | 445.00 |
|  | Yoghurt | 409.00 | 998.00 |