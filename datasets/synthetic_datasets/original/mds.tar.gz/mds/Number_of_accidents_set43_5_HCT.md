|  |  | Male | Female |
|---|---|---|---|
| Fire | Fatal | 40.00 | 87.00 |
|  | Average | 40.00 | 87.00 |
| Traffic | Fatal | 26.00 | 17.00 |
|  | Average | 26.00 | 17.00 |
| Drowning | Fatal | 35.00 | 28.00 |
|  | Average | 35.00 | 28.00 |
| Average |  | 33.67 | 44.00 |